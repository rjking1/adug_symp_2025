# global constants

# app main window positions
screen_left = 100
screen_top=0
screen_width=1600
screen_height=900

# image capturing - chop window's borders off
crop_border_left=7
crop_border_top=7 
crop_border_right=14 # 2 borders to go
crop_border_bottom=14

# image comparison - chop off menu etc and FT
crop_image_left=300
crop_image_top=100