import os

# config for all combinations of xCADs, product versions and machines (IDs)

# ------------- WARNING --------------
# be very careful with what is set as the collab_folder
# the tests remove that folder at the start of some tests
# so anything in it will be gone
# you have been warned !

# generic_title_re is a regular expression which allows for variation in the title across product versions
# source_folder and data_reader_exe_path must be relative paths as the tests can
#   run in c:\products\... or c:\testing\products\...
# the app_data_folder is where the log files that record what incremental files have been applied are located

# product abbrev must be 2 or 3 letters and lowercase, currently inv or sw

# The ID after inv or sw must be a unique identifier eg WADDY so we can have the same MCAD product including year
# eg SW2021 on multiple machines
# yet share this one config file across all machines/users from the repo

# collab_folder is using backslashes as Windows open dialog does not like forward slashes.
# TODO: would be better to handle in python scripts


def config(product):
    return {
        "calc_RKASUS": {
            "generic_title_re": "Calc.*",
            "source_folder": r"./testdata/",
        },        
        "calc_DELLEO": {
            "generic_title_re": "Calc.*",
            "source_folder": r"./testdata/",
        },
    }[product + "_" + os.getenv("ID")]
