from calc_app import CalcApp
from typing import override

from seleniumbase import BaseCase
from seleniumbase.behave import behave_sb
from seleniumbase.behave.behave_sb import before_all  # noqa
from seleniumbase.behave.behave_sb import before_feature  # noqa
from seleniumbase.behave.behave_sb import before_scenario  # noqa
from seleniumbase.behave.behave_sb import before_step  # noqa
from seleniumbase.behave.behave_sb import after_step  # noqa
from seleniumbase.behave.behave_sb import after_scenario  # noqa
from seleniumbase.behave.behave_sb import after_feature  # noqa
from seleniumbase.behave.behave_sb import after_all  # noqa



class WebCalcApp(CalcApp):

    # def __init__(self, context):
    # #     # self.b = context.sb
    # #     self.dlg = behave_sb.get_configured_sb(context)
    #     self.c = context

    def start(self):
        pass

    def startWeb(self,context):
        behave_sb.set_base_class(BaseCase)  # Accepts a BaseCase subclass
        context.sb.open("https://seleniumbase.io/apps/calculator")

    def reset_calc(self):
        self.b.click("button#clear")


    def clickExpression(self, expr):
        for k in expr:
            pass
        #     self.dlg.window(title=k, class_name='TButton').click()
        # self.dlg.window(title='=', class_name='TButton').click()

    def getResult(self):
        # display = self.dlg.Edit
        # txt = display.get_value()
        return txt
