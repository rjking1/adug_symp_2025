from typing import override
from pywinauto import Desktop, Application
from calc_app import CalcApp
import time


class WinCalcApp(CalcApp):
    @override
    def start(self):
        self.app = Application(backend="uia").start("calc.exe")
        self.dlg = Desktop(backend="uia").Calculator

    def reset_calc(self):
        self.dlg.type_keys("{ESC}")

    def clickExpression(self, expr):
        for k in expr:
            if k == "+":
                auto_id = "plusButton"
            elif k == "-":
                auto_id = "minusButton"
            elif k == "*":
                auto_id = "multiplyButton"
            elif k == "/":
                auto_id = "divideButton"
            else:
                auto_id = "num" + k + "Button"
            self.dlg.window(auto_id=auto_id, control_type="Button").click()
            time.sleep(0.1)
        self.dlg.window(auto_id="equalButton", control_type="Button").click()
        # time.sleep(1)

    def getResult(self):
        txt = self.dlg.Static3.texts()
        # Get only the numeric value
        return txt[0].split(" ")[2]
