from typing import override
from pywinauto import Desktop, Application
from calc_app import CalcApp


class ChatGPTCalcApp(CalcApp):
    @override
    def start(self):
        self.app = Application(backend="uia").start("chatgpt.exe")
        self.dlg = Desktop(backend="uia").Calculator

    def reset_calc(self):
        self.dlg.type_keys("{ESC}") # like WinCalc and unlike DCalc

    def clickExpression(self, expr):
        for k in expr:
            self.dlg.window(title=k, class_name='TButton').click()
        self.dlg.window(title='=', class_name='TButton').click()

    def getResult(self):
        display = self.dlg.Edit
        txt = display.get_value()
        return txt
