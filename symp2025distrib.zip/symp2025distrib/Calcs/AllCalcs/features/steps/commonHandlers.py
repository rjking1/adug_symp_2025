# given, when, then handlers 
# idea is to force the feature file to have statements that apply to all apps

from behave import *

from calc_WinCalc import WinCalcApp
from calc_DCalc import DCalcApp
from calc_ChatGPT import ChatGPTCalcApp
from calc_WebCalc import WebCalcApp

@step("I start the calculator")
def step_impl(context):
    tagsList = f"{context.config.tags}".split()
    if 'WinCalc' in tagsList:
        context.app = WinCalcApp()

    elif 'DCalc' in tagsList:
        context.app = DCalcApp()

    elif 'ChatGPT' in tagsList:
        context.app = ChatGPTCalcApp()

    elif 'WebCalc' in tagsList:
        context.app = WebCalcApp()
        context.app.startWeb(context)

    context.app.start()

@given(u'I reset the calculator')
def step_impl(context):
    context.app.reset_calc()

@when(u'I input {expr}')
def step_impl(context, expr):
    context.app.typeExpression(expr)

@when(u'I click {expr}')
def step_impl(context, expr):
    context.app.clickExpression(expr)

@then(u'I should get {expected}')
def step_impl(context, expected):
    got = context.app.getResult()
    # print(res)
    assert got == expected, f'expected {expected}, got {got}'

@then("close the calculator")
def step_impl(context):
    context.app.close_app()

@step("Capture screen as {name}")
def step_impl(context, name):
    context.app.capture_screen(name)
