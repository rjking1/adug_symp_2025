# base class for all calculators

from pywinauto import Application, mouse
import os
from datetime import datetime
import time
from PIL import Image
import allure
from const import *


class CalcApp:
    def __init__(self):
        pass

    def start(self):
        pass

    def typeExpression(self, expr):
        for k in expr:
            if k == "+":
                # '+' is a special char meaning SHIFT so have to send VK code
                k = "{VK_ADD}"
            self.dlg.type_keys(k)
            # Add a small delay between each key stroke
            time.sleep(0.1)
        self.dlg.type_keys("=")
        # time.sleep(1)


    def capture_screen(self, name):
        time.sleep(0.5)
        fname = _makeOutputFolderFromDate() + _genFileName(name)

        # move mouse to (0,0) to stop tooltips being captured
        mouse.move() 
        img = self.dlg.capture_as_image()

        # https://www.geeksforgeeks.org/python-pil-image-crop-method/
        # crop window to remove transparent border
        width, height = img.size
        img = img.crop((crop_border_left, crop_border_top, width - crop_border_right, height - crop_border_bottom)) # (left, top, right, bottom)
        img.save(fname)  

        # attach to allure report
        allure.attach.file(fname, name=name, attachment_type=allure.attachment_type.PNG)


    def close_app(self):
        self.dlg.close()

def _makeOutputFolderFromDate():
    path = f"./screenshots/"
    os.makedirs(path, exist_ok=True)
    return path


def _genFileName(name):
    current_datetime = datetime.now().strftime("%Y%m%d-%H%M%S")
    return "calc-" + str(current_datetime) + "-" + name + ".png"
