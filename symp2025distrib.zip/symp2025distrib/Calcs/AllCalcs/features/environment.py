# hooks

# send summary to slack at end of run

# going to add logging and pass/fail/skip/soft fail(= fail, but continue) handling here

# intention is to make this functionaliy as similar as possible to
# that for seleniumbase
# put all common logic in notifier.py which is shared by all (jira and slack notifications)

from steps.config import config
import os
import re
import subprocess
from datetime import datetime
# for experimental csv reader: 3..
from behave.model import ScenarioOutline, Table
import csv
import copy


def setAppVers(context, tags):
    # must run multiple behave invocations if have multiple versions of one app on a machine
    # vers = os.getenv("VERS") # must be in form eg sw2021 or inv2020 and can be a list eg sw2021,inv2020
    # assert vers != None, "Environment var VERS must be defined"

    context.appIs = "calc"
    context.appVers = ""


n_scenarios_tested = 0

# def before_all(context):
#     context.passed_scenarios = []
#     context.failed_scenarios = []
#     context.soft_fail_scenarios = []
#     context.differs = []
#     context._summary = ""

#     slackSend(context, f"\n🔆 Start: ID={os.getenv("ID", "")} VERS={os.getenv("VERS", "")} OPTIONS={os.getenv("OPTIONS", "")}\nTags={context.config.tags}")

#     kv = f"ID={os.getenv('ID')}"
#     kv += f"\nVERS={os.getenv('VERS')}"
#     kv += f"\nTAGS={context.config.tags}"
#     kv += f"\nGit HEAD={subprocess.check_output(['git', 'rev-parse', '--short', 'HEAD']).decode('ascii').strip()}"

#     f = open(
#         "./allure-results/environment.properties",
#         "w",
#         encoding="utf-8",
#     )
#     f.write(kv)
#     f.close()


# def before_feature(context, feature):
#     print(f"\nRunning feature {feature.name} with tags: {context.config.tags}")

#     # so that we know what is running...
#     slackSend(context, f"\n🔆 Running: '{feature.name}'. ID={os.getenv("ID", "")} VERS={os.getenv("VERS", "")}") # OPTS={os.getenv("OPTIONS", "")} 


def before_scenario(context, scenario):
#     # build more useful name for reporting
    setAppVers(context, scenario.tags) # .effective_tags
#     # context.scenario_name = scenario.name + " " + ",".join(scenario.tags) + " v" + context.appVers
#     context.scenario_name = scenario.name + " " + context.appIs + context.appVers  # add ID?
#     context.scenario_warnings = ""
#     context._scenario_tags = scenario.tags

#     print("\nTesting scenario ", context.scenario_name, "...")

#     # only those tagged
#     # def before_scenario(context, scenario):
    if "runner.continue_after_failed_step" in scenario.effective_tags:
        scenario.continue_after_failed_step = True


# def before_step(context, step):
#     # for assertEx to use
#     context.step_name = step.name
#     context.step_line = step.line


# def after_step(context, step):
#     # if step.status == "failed":
#     # step.error_message is not set here (as the hook may fail)
#     # see https://github.com/behave/behave/issues/468
#     # so have to find in after_scenario by iterating over all steps
#     # and finding the first one marked with a failed status
#     # slackSend( f":x: {step.filename} line # {step.line}: {step.name}: {step.status.name}\n{step.error_message}")
#     pass


# def after_scenario(context, scenario):
#     pass

#     global n_scenarios_tested

#     last_good_result = ""
#     if "diffs" in scenario.tags:
#         # read last_good_result for comparison
#         file_name = (
#             config(context.appIs)["source_folder"]
#             + context._base_folder
#             + f"/results_{context._idx}.txt"
#         )
#         if os.path.isfile(file_name):
#             f = open(file_name, "r", encoding="utf-8",)
#             last_good_result = f.read()
#             f.close()

#     dur = round(scenario.duration)
#     dur = f"{dur // 60}:{str(dur % 60).zfill(2)}"

#     n_scenarios_tested += 1
#     result = f"{context.scenario_name} took {dur}. {scenario.status.name}"
#     if scenario.status.name == "passed":
#         if context.scenario_name not in context.soft_fail_scenarios:
#             if context.scenario_name not in context.passed_scenarios:            
#                 context.passed_scenarios.append(context.scenario_name)
#             if "HidePasses" not in os.getenv("OPTIONS", ""):
#                 result = f"\n✅ {result}"
#                 # white_check_mark = green tick
#                 slackSend(context, result)
#         else:
#             # had warnings
#             result = f"\n❎ {result} with warnings:\n{context.scenario_warnings}"
#             slackSend(context, result)

#     elif scenario.status.name == "failed":
#         # this must be a hard failure
#         # as a soft fail will not have set the scenario/step status to failed

#         if context.scenario_name not in context.failed_scenarios:            
#             context.failed_scenarios.append(context.scenario_name)

#         # capture cpu and mem usage
#         import psutil
#         result += f"\nCPU usage %={psutil.cpu_percent(4)}"        
#         result += f"\nMem usage %={psutil.virtual_memory()[2]}"        
    
#         # capture a screen shot
#         from steps.utils import captureScreen
#         # captureScreen(context, context._base_folder + "_" + str(context._idx) + "_fail")
#         captureScreen(context, context.scenario_name + "_fail")

#         # capture the error details (as seen in html report)
#         # by finding the failed step
#         for step in scenario.steps:
#             if step.status.name == "failed":
#                 result = f"\n❌ {result}\n{step.error_message}"
#                 slackSend(context,result)
#                 break
#         else:
#             print("\nInternal error: could not find failed step!")

#     else: 
#         print("\nInternal error: unhandled status!")

#     print(re.sub('[^\x00-\x7F]', '', result)) # print_sanitized()

#     # if failed then don't report if different to last good - no point !
#     # don't concat last_good_results to results ! else they will accum forever !!

#     if "diffs" in scenario.tags and \
#             last_good_result != "" and \
#             scenario.status.name != "failed" and \
#             "ShowDiffs" in os.getenv("OPTIONS", "") and \
#             filter_variable_stuff(result) != filter_variable_stuff(last_good_result):
#         context.differs.append(context.scenario_name)
#         print(re.sub('[^\x00-\x7F]', '', f"\n⚠️ This result differs from the last good result:"))
#         print(re.sub('[^\x00-\x7F]', '', last_good_result))
#         slackSend(context, f"\n⚠️ This result differs from the last good result:")
#         slackSend(context, block_quote(last_good_result))

#     # keep only "good" results for future comparison
#     if "diffs" in scenario.tags and scenario.status.name != "failed" :
#         # write result to compare in future run
#         f = open(
#             config(context.appIs)["source_folder"]
#             + context._base_folder
#             + f"/results_{context._idx}.txt",
#             "w", encoding="utf-8",
#         )
#         f.write(result)
#         f.close()


# def filter_variable_stuff(result):
#     t = re.sub(r"took \d+:\d\d", "", result) 
#     t = re.sub(r"line # \d+:", "", t) 
#     t = re.sub(r"^CPU usage.*$", "", t) 
#     t = re.sub(r"^Mem usage.*$", "", t) 
#     t = re.sub(r" @\d+\.\d+ ", "", t) 
#     return t

# def block_quote(s):
#     return '>'.join(s.splitlines(True))


# def after_feature(context, feature):
#     dur = round(feature.duration)
#     dur = f"{dur // 60}:{str(dur % 60).zfill(2)}"

#     hdr = f"{feature.name} ID={os.getenv("ID", "")} VERS={os.getenv("VERS", "")} took {dur}"
#     print(f"\n{hdr}")
#     slackSend(context, f"\n⏰ {hdr}")


# def after_all(context):
#     global n_scenarios_tested

#     sym = u"🟢"
#     if len(context.soft_fail_scenarios) > 0:
#         sym = u"🟠"
#     if len(context.failed_scenarios) > 0:
#         sym = u"🔴"

#     summary = ""
    
#     failed = ""
#     for name in context.failed_scenarios:
#         failed = failed + "\n" + name
#     if failed != "":
#         summary = summary + f"\n❌ Failed tests:{failed}"

#     # soft_failed = ""
#     # for name in context.soft_fail_scenarios:
#     #     soft_failed = soft_failed + "\n" + name
#     # if soft_failed != "":
#     #     summary = summary + f"\n❎ Tests with warnings:{soft_failed}"

#     # diff_tests = ""
#     # for name in context.differs:
#     #     diff_tests = diff_tests + "\n" + name
#     # if diff_tests != "":
#     #     summary = summary + f"\n⚠️ Tests with a different result to previous run:{diff_tests}"

#     footer = f"\nID={os.getenv("ID", "")} VERS={os.getenv("VERS", "")} Git HEAD={subprocess.check_output(['git', 'rev-parse', '--short', 'HEAD']).decode('ascii').strip()}\n{sym} {n_scenarios_tested} tests run; {len(context.passed_scenarios)} passed; {len(context.soft_fail_scenarios)} had warnings; {len(context.failed_scenarios)} failed"
#     dashes = "\n" + ("-" * len(footer))

#     summary = dashes + summary + footer + dashes

#     # causes UnicodeEncodeError: 'charmap' codec can't encode character '\u274e' in position 829: character maps to <undefined>
#     print(re.sub('[^\x00-\x7F]', '', summary))

#     slackSend(context, summary)
#     slackSend(context, f"\n🔆 End: ID={os.getenv("ID", "")} VERS={os.getenv("VERS", "")} OPTIONS={os.getenv("OPTIONS", "")}\nTags={context.config.tags}")

#     writeSummary(context)


# def countSoftFail(context):
#     if context.scenario_name not in context.soft_fail_scenarios:            
#         context.soft_fail_scenarios.append(context.scenario_name)


# def slackSend(context, message):

#     context._summary += "\n" + message

#     if os.getenv("SLACK_URL") == None or "NoSlack" in os.getenv("OPTIONS", ""):
#         return

#     from slack_sdk.webhook import WebhookClient

#     url = os.getenv("SLACK_URL")
#     webhook = WebhookClient(url)

#     response = webhook.send(text=message)
#     assert response.status_code == 200
#     # assert response.body == "ok"


# def makeReportName(context):
#     sanitized_tags = f"{context.config.tags}"
#     sanitized_tags = sanitized_tags.replace("-skip", "")
#     sanitized_tags = sanitized_tags.replace("@", "")
#     sanitized_tags = sanitized_tags.replace(" ", "-")
#     current_datetime = datetime.now().strftime("%Y%m%d-%H%M")
#     return f"{current_datetime}-{sanitized_tags}"


# def writeSummary(context):
#     os.makedirs("./reports/", exist_ok=True)
#     fname = f"./reports/{makeReportName(context)}.txt"
#     f = open(fname, "w", encoding="utf-8",)
#     f.write(context._summary)
#     f.close()

#     # attach to allure report
#     # this is not visible in Allure at all
#     # so is a waste of time (prob an allure-behave limitation)
    
#     # allure.attach.file(
#     #     fname,
#     #     name=sanitized_tags,
#     #     attachment_type=allure.attachment_type.TEXT
#     # )
